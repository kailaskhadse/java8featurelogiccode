package Task;

public class CharacterFrequencyCounterBase {
 public void characterFrequencyCounting(String s){
	 
 }

}
