package Task;

public interface CharacterFrequencyCountable {
void countCharacterFrequencies(String s);
}
